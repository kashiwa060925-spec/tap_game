'use strict';
// シンプル・タップ（骨組み）
const SAVE_KEY = 'tap_skeleton_v1';

const $ = (s)=>document.querySelector(s);
const countEl = $('#count');
const tapBtn  = $('#tapBtn');
const autoBtn = $('#autoBtn');
const saveBtn = $('#saveBtn');
const resetBtn= $('#resetBtn');
const statusEl= $('#status');

const state = { count:0, auto:false };

function load(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw) return;
    const o = JSON.parse(raw);
    state.count = o.count||0;
    state.auto  = !!o.auto;
  }catch(_){ /* ignore */ }
}

function save(msg=false){
  try{
    localStorage.setItem(SAVE_KEY, JSON.stringify({count:state.count, auto:state.auto}));
    if(msg) setStatus('保存しました');
  }catch(_){ setStatus('保存失敗'); }
}

function setStatus(t){ if(statusEl) statusEl.textContent=t; }
function render(){
  if(countEl) countEl.textContent = state.count.toString();
  if(autoBtn){
    autoBtn.setAttribute('aria-pressed', state.auto?'true':'false');
    autoBtn.textContent = `自動 +1/秒：${state.auto?'ON':'OFF'}`;
  }
}

let last = performance.now();
function loop(ts){
  const dt = Math.min(0.25, (ts - last)/1000);
  last = ts;
  if(state.auto){
    // dtを積算（簡易）: 1秒未満でもなめらかに増やす
    state.count += dt;
  }
  render();
  requestAnimationFrame(loop);
}

if(tapBtn) tapBtn.addEventListener('click', ()=>{ state.count += 1; });
if(autoBtn) autoBtn.addEventListener('click', ()=>{ state.auto = !state.auto; render(); });
if(saveBtn) saveBtn.addEventListener('click', ()=> save(true));
if(resetBtn) resetBtn.addEventListener('click', ()=>{
  if(!confirm('リセットしますか？')) return;
  state.count = 0; state.auto=false; save(true); render();
});

load();
render();
setStatus('READY');
requestAnimationFrame(loop);
